package com.example.decisionsupportsystem

object URLs {
    private const val ROOT_URL = "http://192.168.1.4/Android/Api.php?apicall="
    const val URL_REGISTER = ROOT_URL + "signup"
    const val URL_LOGIN = ROOT_URL + "login"
}