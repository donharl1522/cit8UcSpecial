package com.example.decisionsupportsystem

class User(
    /**
     * Created by Belal on 9/5/2017.
     */
    //this is very simple class and it only contains the user attributes, a constructor and the getters
    // you can easily do this by right click -> generate -> constructor and getters
    val id: Int, val username: String, val association: String
)