<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pasya</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST']  ?>/cit8UcSpecial-master/css/mdb.min.css" />
    <link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST']  ?>/cit8UcSpecial-master/css/admin.css" />
    <link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST']  ?>/cit8UcSpecial-master/css/style.css" />

    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>